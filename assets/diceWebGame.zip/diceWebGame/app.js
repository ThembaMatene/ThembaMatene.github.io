
const rollDiceButton = document.querySelector("#rollDice");

rollDiceButton.addEventListener("click", function(){
const dice1Value = Math.floor(Math.random() * 6) + 1
const dice1img = 'images/dice' + dice1Value + '.png';
document.querySelectorAll('img')[0].setAttribute('src', dice1img);

const dice2Value = Math.floor(Math.random() * 6) + 1
const dice2img = 'images/dice' + dice2Value + '.png';
document.querySelectorAll('img')[1].setAttribute('src', dice2img);
});     

